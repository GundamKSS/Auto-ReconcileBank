"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Search,
  Bell,
  Plus,
  RotateCcw,
  Sparkles,
  X,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  PanelLeft,
  Loader2,
  AlertTriangle,
} from "lucide-react";

type Direction = "IN" | "OUT";
type BankTab = "ALL" | "BBL" | "KBANK" | "SCB";

type BankApiLine = {
  id: string;
  lineId: number;
  bankCode: string;
  date: string;
  ref: string;
  direction: Direction;
  description: string;
  amount: number;
};

type GlApiLine = {
  id: string;
  entryNo: number;
  bankCode: string;
  date: string;
  ref: string;
  direction: Direction;
  description: string;
  amount: number;
};

type LineItem = {
  id: string;
  bankCode: string;
  date: string;
  ref: string;
  direction: Direction;
  description: string;
  amount: number;
};

type FilterValue = "ALL" | "IN" | "OUT";

const BANK_TABS: { code: BankTab; label: string }[] = [
  { code: "ALL", label: "All banks" },
  { code: "BBL", label: "BBL" },
  { code: "KBANK", label: "KBank" },
  { code: "SCB", label: "SCB" },
];

function formatAmount(n: number) {
  return n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatDate(iso: string) {
  return new Date(iso).toISOString().slice(0, 10);
}

function DirectionBadge({ direction }: { direction: Direction }) {
  const isIn = direction === "IN";
  return (
    <span
      className={`inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full ${
        isIn ? "bg-teal-50 text-teal-700" : "bg-red-50 text-red-600"
      }`}
    >
      {isIn ? <ArrowDownLeft size={12} /> : <ArrowUpRight size={12} />}
      {direction}
    </span>
  );
}

function FilterTabs({ value, onChange }: { value: FilterValue; onChange: (v: FilterValue) => void }) {
  const options: FilterValue[] = ["ALL", "IN", "OUT"];
  return (
    <div className="flex items-center gap-1 shrink-0">
      {options.map((opt) => (
        <button
          key={opt}
          onClick={() => onChange(opt)}
          className={`text-xs font-medium px-2.5 py-1 rounded-full transition-colors ${
            value === opt ? "bg-blue-600 text-white" : "text-gray-400 hover:text-gray-600"
          }`}
        >
          {opt}
        </button>
      ))}
    </div>
  );
}

// แท็บแยกธนาคาร ใช้ได้ทั้งฝั่ง Bank statement และฝั่ง GL (โชว์จำนวนรายการ pending ต่อธนาคารกำกับไว้ด้วย)
function BankTabs({
  items,
  value,
  onChange,
}: {
  items: { bankCode: string }[];
  value: BankTab;
  onChange: (v: BankTab) => void;
}) {
  const counts = useMemo(() => {
    const c: Record<string, number> = { ALL: items.length };
    for (const item of items) c[item.bankCode] = (c[item.bankCode] ?? 0) + 1;
    return c;
  }, [items]);

  return (
    <div className="flex items-center gap-1.5 px-4 pt-2.5 pb-1 flex-wrap shrink-0">
      <span className="text-[11px] text-gray-400 mr-0.5">All banks</span>
      {BANK_TABS.map((tab) => (
        <button
          key={tab.code}
          onClick={() => onChange(tab.code)}
          className={`text-xs font-medium px-2.5 py-1 rounded-full transition-colors ${
            value === tab.code ? "bg-gray-900 text-white" : "bg-gray-100 text-gray-500 hover:bg-gray-200"
          }`}
        >
          {tab.code === "ALL" ? "All" : tab.label} {counts[tab.code] ?? 0}
        </button>
      ))}
    </div>
  );
}

function Panel({
  title,
  allItems,
  bankTab,
  onBankTabChange,
  selected,
  onToggle,
  filter,
  onFilterChange,
  loading,
}: {
  title: string;
  allItems: LineItem[];
  bankTab: BankTab;
  onBankTabChange: (v: BankTab) => void;
  selected: Set<string>;
  onToggle: (id: string) => void;
  filter: FilterValue;
  onFilterChange: (v: FilterValue) => void;
  loading: boolean;
}) {
  const byBank = bankTab === "ALL" ? allItems : allItems.filter((i) => i.bankCode === bankTab);
  const filtered = byBank.filter((item) => filter === "ALL" || item.direction === filter);

  return (
    <div className="flex flex-col bg-white border border-gray-200 rounded-2xl overflow-hidden min-w-0 lg:h-full">
      <div className="flex items-center justify-between gap-3 px-4 py-3 border-b border-gray-100 flex-wrap shrink-0">
        <div className="flex items-baseline gap-2 min-w-0">
          <h2 className="font-semibold text-[15px] text-gray-900 whitespace-nowrap">{title}</h2>
          <span className="text-xs text-gray-400 whitespace-nowrap">
            {selected.size} selected · {filtered.length} pending
          </span>
        </div>
        <FilterTabs value={filter} onChange={onFilterChange} />
      </div>

      <BankTabs items={allItems} value={bankTab} onChange={onBankTabChange} />

      <div className="flex flex-col divide-y divide-gray-50 overflow-y-auto max-h-[55vh] lg:max-h-none lg:flex-1 lg:min-h-0">
        {loading && (
          <div className="px-4 py-10 text-center text-sm text-gray-400 flex items-center justify-center gap-2">
            <Loader2 size={16} className="animate-spin" /> กำลังโหลด...
          </div>
        )}
        {!loading && filtered.length === 0 && (
          <div className="px-4 py-10 text-center text-sm text-gray-400">ไม่มีรายการค้างจับคู่</div>
        )}
        {!loading &&
          filtered.map((item) => {
            const isSelected = selected.has(item.id);
            return (
              <label
                key={item.id}
                className={`flex items-center gap-3 px-4 py-3 cursor-pointer transition-colors ${
                  isSelected ? "bg-blue-50/60" : "hover:bg-gray-50"
                }`}
              >
                <input
                  type="checkbox"
                  checked={isSelected}
                  onChange={() => onToggle(item.id)}
                  className="w-4 h-4 rounded border-gray-300 shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 text-xs text-gray-400 mb-0.5 flex-wrap">
                    <span className="whitespace-nowrap">
                      {formatDate(item.date)} · {item.ref}
                    </span>
                    <span className="text-[10px] font-semibold text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded">
                      {item.bankCode}
                    </span>
                    <DirectionBadge direction={item.direction} />
                  </div>
                  <p className="text-sm text-gray-800 truncate">{item.description}</p>
                </div>
                <span className="text-sm font-medium text-gray-900 tabular-nums whitespace-nowrap">
                  {formatAmount(item.amount)}
                </span>
              </label>
            );
          })}
      </div>
    </div>
  );
}

export default function ReconcileWorkspace() {
  const [bankSideTab, setBankSideTab] = useState<BankTab>("ALL");
  const [glSideTab, setGlSideTab] = useState<BankTab>("ALL");
  const [bankFilter, setBankFilter] = useState<FilterValue>("ALL");
  const [glFilter, setGlFilter] = useState<FilterValue>("ALL");
  const [selectedBank, setSelectedBank] = useState<Set<string>>(new Set());
  const [selectedGl, setSelectedGl] = useState<Set<string>>(new Set());

  const [bankLines, setBankLines] = useState<BankApiLine[]>([]);
  const [glLines, setGlLines] = useState<GlApiLine[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [actionMessage, setActionMessage] = useState("");
  const [busy, setBusy] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      // ไม่ใส่ bankCode = ดึงทุกธนาคารมาครั้งเดียว แล้วให้แท็บทำหน้าที่กรองฝั่ง client แทน
      const res = await fetch(`/api/reconcile/data`);
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "โหลดข้อมูลไม่สำเร็จ");
        return;
      }
      setBankLines(data.bankLines);
      setGlLines(data.glLines);
      setSelectedBank(new Set());
      setSelectedGl(new Set());
    } catch {
      setError("เชื่อมต่อ server ไม่ได้");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  function toggleBank(id: string) {
    setSelectedBank((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  function toggleGl(id: string) {
    setSelectedGl((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  const selectedBankItems = useMemo(
    () => bankLines.filter((l) => selectedBank.has(l.id)),
    [selectedBank, bankLines]
  );
  const selectedGlItems = useMemo(() => glLines.filter((l) => selectedGl.has(l.id)), [selectedGl, glLines]);

  const bankTotal = useMemo(() => selectedBankItems.reduce((sum, l) => sum + l.amount, 0), [selectedBankItems]);
  const glTotal = useMemo(() => selectedGlItems.reduce((sum, l) => sum + l.amount, 0), [selectedGlItems]);
  const difference = bankTotal - glTotal;

  // validation: ทุกรายการที่เลือก (ทั้ง 2 ฝั่งรวมกัน) ต้องเป็นธนาคารเดียวกันเท่านั้น ห้ามข้ามธนาคาร
  const selectedBankCodes = useMemo(() => {
    const codes = new Set<string>();
    selectedBankItems.forEach((i) => codes.add(i.bankCode));
    selectedGlItems.forEach((i) => codes.add(i.bankCode));
    return codes;
  }, [selectedBankItems, selectedGlItems]);
  const hasCrossBankSelection = selectedBankCodes.size > 1;

  // validation: วันที่ของทุกรายการที่เลือก (ทั้ง 2 ฝั่ง) ต้องตรงกันหมด ตามเงื่อนไข Posting Date ต้องเท่ากับ Tran Date เป๊ะ
  const selectedDates = useMemo(() => {
    const dates = new Set<string>();
    selectedBankItems.forEach((i) => dates.add(formatDate(i.date)));
    selectedGlItems.forEach((i) => dates.add(formatDate(i.date)));
    return dates;
  }, [selectedBankItems, selectedGlItems]);
  const hasDateMismatch = selectedDates.size > 1;

  const amountMatches = Math.abs(difference) < 0.005;
  const canMatch =
    selectedBank.size > 0 &&
    selectedGl.size > 0 &&
    amountMatches &&
    !hasCrossBankSelection &&
    !hasDateMismatch;
  const canMoveToSuspense = selectedBank.size > 0 || selectedGl.size > 0;

  function handleClear() {
    setSelectedBank(new Set());
    setSelectedGl(new Set());
  }

  // ธนาคารที่จะใช้ยิง API (match ต้องมี bankCode เดียวชัดเจนเสมอ อนุมานจากรายการที่เลือก)
  const matchBankCode = selectedBankCodes.size === 1 ? [...selectedBankCodes][0] : null;

  async function handleMatch() {
    if (!canMatch || busy || !matchBankCode) return;
    setBusy(true);
    setActionMessage("");
    try {
      const res = await fetch("/api/reconcile/match", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          bankCode: matchBankCode,
          matchType: "MATCHED",
          bankLineIds: selectedBankItems.map((l) => l.lineId),
          glEntryNos: selectedGlItems.map((l) => l.entryNo),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setActionMessage(data.error || "Match ไม่สำเร็จ");
        return;
      }
      setActionMessage(`จับคู่สำเร็จ (Bank ${selectedBank.size} : GL ${selectedGl.size})`);
      await loadData();
    } catch {
      setActionMessage("เชื่อมต่อ server ไม่ได้");
    } finally {
      setBusy(false);
    }
  }

  async function handleMoveToSuspense() {
    if (!canMoveToSuspense || busy) return;
    // suspense ไม่บังคับ bank เดียวกัน (เช่น เงินเข้าไม่ทราบที่มา อาจไม่มีฝั่ง GL เลยด้วยซ้ำ) แต่ต้องมี bankCode ส่งไปสักค่า
    const bankCodeToUse = matchBankCode ?? selectedBankItems[0]?.bankCode ?? selectedGlItems[0]?.bankCode;
    if (!bankCodeToUse) return;

    setBusy(true);
    setActionMessage("");
    try {
      const res = await fetch("/api/reconcile/match", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          bankCode: bankCodeToUse,
          matchType: "SUSPENSE",
          bankLineIds: selectedBankItems.map((l) => l.lineId),
          glEntryNos: selectedGlItems.map((l) => l.entryNo),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setActionMessage(data.error || "ย้ายเข้าบัญชีพักไม่สำเร็จ");
        return;
      }
      setActionMessage("ย้ายเข้าบัญชีพักโอนแล้ว");
      await loadData();
    } catch {
      setActionMessage("เชื่อมต่อ server ไม่ได้");
    } finally {
      setBusy(false);
    }
  }

  async function handleSuggestMatches() {
    if (busy) return;
    if (bankSideTab === "ALL") {
      setActionMessage("เลือกแท็บธนาคารที่ต้องการก่อน ถึงจะ Suggest matches ได้ (ไม่รองรับข้ามธนาคารพร้อมกัน)");
      return;
    }
    setBusy(true);
    setActionMessage("");
    try {
      const res = await fetch("/api/reconcile/suggest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bankCode: bankSideTab }),
      });
      const data = await res.json();
      if (!res.ok) {
        setActionMessage(data.error || "Suggest matches ไม่สำเร็จ");
        return;
      }
      setActionMessage(
        data.matchedCount > 0
          ? `จับคู่อัตโนมัติสำเร็จ ${data.matchedCount} รายการ (เฉพาะที่วันที่+ยอดตรงกันเป๊ะ)`
          : "ไม่พบรายการที่จับคู่กันได้แบบ 1:1 ชัดเจน — ลองเลือกจับคู่เองสำหรับเคสยอดรวม (lump sum)"
      );
      await loadData();
    } catch {
      setActionMessage("เชื่อมต่อ server ไม่ได้");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex-1 min-w-0 flex flex-col bg-gray-50 lg:h-full lg:overflow-hidden">
      {/* Top bar */}
      <div className="flex items-center gap-3 px-4 sm:px-6 py-3 bg-white border-b border-gray-100 flex-wrap shrink-0">
        <button className="p-1.5 text-gray-400 hover:text-gray-600 shrink-0" aria-label="Toggle sidebar">
          <PanelLeft size={18} />
        </button>
        <div className="flex items-center gap-1.5 text-sm text-gray-500 shrink-0">
          <span>Home</span>
          <span>/</span>
          <span className="text-gray-900 font-medium">Reconcile</span>
        </div>

        <div className="flex-1 min-w-[160px] order-3 sm:order-none">
          <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 max-w-md">
            <Search size={16} className="text-gray-400 shrink-0" />
            <input
              placeholder="Search transactions, references..."
              className="bg-transparent text-sm outline-none w-full placeholder:text-gray-400"
            />
          </div>
        </div>

        <button className="relative p-2 text-gray-400 hover:text-gray-600 shrink-0" aria-label="Notifications">
          <Bell size={18} />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-red-500 rounded-full" />
        </button>
        <button className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium px-4 py-2 rounded-lg shrink-0 whitespace-nowrap">
          <Plus size={16} /> New reconciliation
        </button>
      </div>

      {/* Page header */}
      <div className="px-4 sm:px-6 py-5 flex items-start justify-between gap-4 flex-wrap shrink-0">
        <div className="min-w-0">
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900">Reconciliation workspace</h1>
          <p className="text-sm text-gray-500 mt-1">
            Bank Cr ↔ GL Dr · Bank Dr ↔ GL Cr · same date · เลือกเองรองรับ 1-to-many (lump sum)
          </p>
          {actionMessage && <p className="text-sm text-blue-700 mt-1">{actionMessage}</p>}
          {error && <p className="text-sm text-red-600 mt-1">{error}</p>}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={loadData}
            disabled={loading || busy}
            className="flex items-center gap-1.5 text-sm text-gray-600 border border-gray-200 px-3.5 py-2 rounded-full hover:bg-gray-50 disabled:opacity-50"
          >
            <RotateCcw size={14} /> Reset
          </button>
          <button
            onClick={handleSuggestMatches}
            disabled={loading || busy}
            className="flex items-center gap-1.5 text-sm font-medium text-blue-600 border border-blue-200 bg-blue-50 px-3.5 py-2 rounded-full hover:bg-blue-100 disabled:opacity-50"
          >
            {busy ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
            Suggest matches
          </button>
        </div>
      </div>

      {/* Panels */}
      <div className="lg:flex-1 lg:min-h-0 px-4 sm:px-6 pb-4 lg:overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:h-full">
          <Panel
            title="Bank statement"
            allItems={bankLines}
            bankTab={bankSideTab}
            onBankTabChange={setBankSideTab}
            selected={selectedBank}
            onToggle={toggleBank}
            filter={bankFilter}
            onFilterChange={setBankFilter}
            loading={loading}
          />
          <Panel
            title="General Ledger (BC365)"
            allItems={glLines}
            bankTab={glSideTab}
            onBankTabChange={setGlSideTab}
            selected={selectedGl}
            onToggle={toggleGl}
            filter={glFilter}
            onFilterChange={setGlFilter}
            loading={loading}
          />
        </div>
      </div>

      {/* Footer summary bar */}
      <div className="shrink-0 px-4 sm:px-6 py-4 bg-white border-t border-gray-100">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-6 flex-wrap">
            <div>
              <p className="text-[11px] font-medium text-gray-400 tracking-wide">BANK TOTAL</p>
              <p className="text-base font-semibold text-gray-900">{formatAmount(bankTotal)}</p>
            </div>
            <div>
              <p className="text-[11px] font-medium text-gray-400 tracking-wide">GL TOTAL</p>
              <p className="text-base font-semibold text-gray-900">{formatAmount(glTotal)}</p>
            </div>
            <div>
              <p className="text-[11px] font-medium text-gray-400 tracking-wide">DIFFERENCE</p>
              <p className={`text-base font-semibold ${amountMatches ? "text-green-600" : "text-red-600"}`}>
                {formatAmount(difference)}
              </p>
            </div>

            {hasCrossBankSelection && (
              <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-full">
                <AlertTriangle size={12} /> เลือกข้ามธนาคาร
              </span>
            )}
            {hasDateMismatch && (
              <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-full">
                <AlertTriangle size={12} /> วันที่ที่เลือกไม่ตรงกัน
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button onClick={handleClear} className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-700 px-3 py-2">
              <X size={14} /> Clear
            </button>
            <button
              onClick={handleMoveToSuspense}
              disabled={!canMoveToSuspense || busy}
              className="text-sm font-medium text-amber-700 bg-amber-50 border border-amber-200 px-4 py-2 rounded-full disabled:opacity-40 disabled:cursor-not-allowed hover:bg-amber-100"
            >
              Move to suspense
            </button>
            <button
              onClick={handleMatch}
              disabled={!canMatch || busy}
              className="flex items-center gap-1.5 text-sm font-medium text-white bg-blue-600 px-4 py-2 rounded-full disabled:opacity-40 disabled:cursor-not-allowed hover:bg-blue-700"
            >
              {busy ? <Loader2 size={14} className="animate-spin" /> : <ArrowLeftRight size={14} />}
              Match {selectedBank.size}:{selectedGl.size}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
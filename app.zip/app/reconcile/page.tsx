import Sidebar from "../../components/Sidebar";
import ReconcileWorkspace from "./components/ReconcileWorkspace";

export const metadata = {
  title: "Reconcile | Auto Recon 365",
  description: "Match GL entries against bank statement lines",
};

export default function ReconcilePage() {
  return (
      <div className="lg:h-screen lg:overflow-hidden bg-[#f8fafc]">
               {/* Sidebar */}
          <Sidebar />
              {/* <div className="pl-[300px] transition-all duration-300"> */}
                 <div className="pl-[300px] flex bg-gray-50 lg:h-screen lg:overflow-hidden" >
                   <ReconcileWorkspace />
              </div>
      </div>
  );
}
import { NextRequest, NextResponse } from 'next/server';
import sql from 'mssql';
import { getPool } from '../../../../lib/db';

// หาคู่ที่ตรงกันแบบ 1:1 เป๊ะ (วันที่เดียวกัน + ยอดเท่ากันเป๊ะ + ทิศทางตรงกันตาม convention การแสดงผล
// ที่ฝั่ง GL Debit ถูกแสดงเป็น 'IN' และ GL Credit แสดงเป็น 'OUT' ให้ตรงกับฝั่งธนาคารอยู่แล้วตอนดึงข้อมูล)
// เคส 1-to-many (ยอดก้อนรวมของ AP) ไม่ทำ auto-suggest ในรอบนี้ เพราะเสี่ยงจับคู่ผิดถ้าใช้ combinatorial matching
// แบบอัตโนมัติ ปล่อยให้ผู้ใช้เลือกด้วยตัวเองจากหน้า Reconcile แทน
export async function POST(req: NextRequest) {
  try {
    const { bankCode, createdBy } = await req.json();
    if (!bankCode) {
      return NextResponse.json({ error: 'ต้องระบุ bankCode' }, { status: 400 });
    }

    const pool = await getPool();

    const bankResult = await pool
      .request()
      .input('bankCode', sql.NVarChar, bankCode)
      .query(`
        SELECT LineId, TranDate, Debit, Credit
        FROM BankStatementLine
        WHERE BankCode = @bankCode AND MatchStatus = 'UNMATCHED'
      `);

    const glResult = await pool
      .request()
      .input('bankCode', sql.NVarChar, bankCode)
      .query(`
        SELECT e.Entry_No, e.Posting_Date, e.Debit_Amount_LCY, e.Credit_Amount_LCY
        FROM BankAccountLedgerEntries e
        JOIN BankAccountMapping m ON m.BankAccountNo = e.Bank_Account_No
        WHERE m.BankCode = @bankCode
          AND NOT EXISTS (
            SELECT 1 FROM ReconciliationMatchLine rml
            WHERE rml.SourceType = 'GL' AND rml.GLEntryNo = e.Entry_No
          )
      `);

    type BankRow = { lineId: number; date: string; direction: 'IN' | 'OUT'; amount: number };
    type GlRow = { entryNo: number; date: string; direction: 'IN' | 'OUT'; amount: number };

    const bankRows: BankRow[] = bankResult.recordset.map((r) => ({
      lineId: r.LineId,
      date: new Date(r.TranDate).toISOString().slice(0, 10),
      direction: r.Credit !== null ? 'IN' : 'OUT',
      amount: Number(r.Credit !== null ? r.Credit : r.Debit),
    }));

    const glRows: GlRow[] = glResult.recordset.map((r) => ({
      entryNo: r.Entry_No,
      date: new Date(r.Posting_Date).toISOString().slice(0, 10),
      direction: Number(r.Debit_Amount_LCY) > 0 ? 'IN' : 'OUT',
      amount: Number(r.Debit_Amount_LCY) > 0 ? Number(r.Debit_Amount_LCY) : Number(r.Credit_Amount_LCY),
    }));

    const usedGl = new Set<number>();
    const pairs: { bankLineId: number; glEntryNo: number }[] = [];

    for (const bankRow of bankRows) {
      const candidate = glRows.find(
        (gl) =>
          !usedGl.has(gl.entryNo) &&
          gl.date === bankRow.date &&
          gl.direction === bankRow.direction &&
          Math.abs(gl.amount - bankRow.amount) < 0.005
      );
      if (candidate) {
        usedGl.add(candidate.entryNo);
        pairs.push({ bankLineId: bankRow.lineId, glEntryNo: candidate.entryNo });
      }
    }

    if (pairs.length === 0) {
      return NextResponse.json({ matchedCount: 0, pairs: [] });
    }

    // บันทึกทุกคู่ที่หาเจอ เป็นคนละ ReconciliationMatch ต่อ 1 คู่ (1:1 ชัดเจน ไม่ปนกัน)
    const transaction = new sql.Transaction(pool);
    await transaction.begin();

    try {
      for (const pair of pairs) {
        const matchReq = new sql.Request(transaction);
        const matchResult = await matchReq
          .input('bankCode', sql.NVarChar, bankCode)
          .input('createdBy', sql.NVarChar, createdBy ?? 'auto-suggest')
          .query(`
            INSERT INTO ReconciliationMatch (BankCode, MatchType, CreatedBy)
            OUTPUT INSERTED.MatchId
            VALUES (@bankCode, 'MATCHED', @createdBy)
          `);
        const matchId = matchResult.recordset[0].MatchId;

        const lineReq1 = new sql.Request(transaction);
        await lineReq1
          .input('matchId', sql.Int, matchId)
          .input('bankLineId', sql.BigInt, pair.bankLineId)
          .query(`INSERT INTO ReconciliationMatchLine (MatchId, SourceType, BankLineId) VALUES (@matchId, 'BANK', @bankLineId)`);

        const lineReq2 = new sql.Request(transaction);
        await lineReq2
          .input('matchId', sql.Int, matchId)
          .input('glEntryNo', sql.BigInt, pair.glEntryNo)
          .query(`INSERT INTO ReconciliationMatchLine (MatchId, SourceType, GLEntryNo) VALUES (@matchId, 'GL', @glEntryNo)`);

        const updateReq = new sql.Request(transaction);
        await updateReq
          .input('lineId', sql.BigInt, pair.bankLineId)
          .query(`UPDATE BankStatementLine SET MatchStatus = 'MATCHED' WHERE LineId = @lineId`);
      }

      await transaction.commit();
      return NextResponse.json({ matchedCount: pairs.length, pairs });
    } catch (err) {
      await transaction.rollback();
      throw err;
    }
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: 'Suggest matches ไม่สำเร็จ' }, { status: 500 });
  }
}
import { NextRequest, NextResponse } from 'next/server';
import sql from 'mssql';
import { getPool } from  '../../../../lib/db';

// bankCode เป็น optional แล้ว: ไม่ใส่ = ดึงทุกธนาคารมาให้หมด (แต่ละแถวมี bankCode ติดมาด้วย
// ให้ฝั่ง client กรองเป็นแท็บเองได้ โดยไม่ต้องยิง API ใหม่ทุกครั้งที่สลับแท็บ)
export async function GET(req: NextRequest) {
  try {
    const bankCode = req.nextUrl.searchParams.get('bankCode'); // null = ทุกธนาคาร
    const pool = await getPool();

    const bankRequest = pool.request();
    if (bankCode) bankRequest.input('bankCode', sql.NVarChar, bankCode);
    const bankResult = await bankRequest.query(`
      SELECT LineId, BankCode, TranDate, Description, Debit, Credit, ChequeNo
      FROM BankStatementLine
      WHERE MatchStatus = 'UNMATCHED'
        ${bankCode ? 'AND BankCode = @bankCode' : ''}
      ORDER BY TranDate DESC, LineId DESC
    `);

    // ฝั่ง GL: join ผ่าน BankAccountMapping เพื่อรู้ว่า entry นี้เป็นของ BankCode ไหน
    // (รวมหลายบัญชีของธนาคารเดียวกันเข้าด้วยกันอัตโนมัติ เพราะ mapping ผูกไว้แล้ว)
    const glRequest = pool.request();
    if (bankCode) glRequest.input('bankCode', sql.NVarChar, bankCode);
    const glResult = await glRequest.query(`
      SELECT e.Entry_No, m.BankCode, e.Posting_Date, e.Document_No, e.Bank_Account_No,
             e.Debit_Amount_LCY, e.Credit_Amount_LCY
      FROM BankAccountLedgerEntries e
      JOIN BankAccountMapping m ON m.BankAccountNo = e.Bank_Account_No
      WHERE NOT EXISTS (
              SELECT 1 FROM ReconciliationMatchLine rml
              WHERE rml.SourceType = 'GL' AND rml.GLEntryNo = e.Entry_No
            )
        ${bankCode ? 'AND m.BankCode = @bankCode' : ''}
      ORDER BY e.Posting_Date DESC, e.Entry_No DESC
    `);

    const bankLines = bankResult.recordset.map((r) => ({
      id: `bank-${r.LineId}`,
      lineId: r.LineId,
      bankCode: r.BankCode,
      date: r.TranDate,
      ref: r.ChequeNo && r.ChequeNo !== '0' ? `Chq ${r.ChequeNo}` : `L-${r.LineId}`,
      direction: r.Credit !== null ? 'IN' : 'OUT',
      description: r.Description,
      amount: r.Credit !== null ? r.Credit : r.Debit,
    }));

    const glLines = glResult.recordset.map((r) => ({
      id: `gl-${r.Entry_No}`,
      entryNo: r.Entry_No,
      bankCode: r.BankCode,
      date: r.Posting_Date,
      ref: r.Document_No,
      direction: Number(r.Debit_Amount_LCY) > 0 ? 'IN' : 'OUT',
      description: `${r.Document_No} · ${r.Bank_Account_No}`,
      amount: Number(r.Debit_Amount_LCY) > 0 ? Number(r.Debit_Amount_LCY) : Number(r.Credit_Amount_LCY),
    }));

    return NextResponse.json({ bankLines, glLines });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: 'ไม่สามารถดึงข้อมูลสำหรับ reconcile ได้' }, { status: 500 });
  }
}
import { NextRequest, NextResponse } from 'next/server';
import sql from 'mssql';
import { getPool } from '../../../../lib/db';

type MatchRequestBody = {
  bankCode: string;
  matchType: 'MATCHED' | 'SUSPENSE';
  bankLineIds: number[];
  glEntryNos: number[];
  createdBy?: string;
};

export async function POST(req: NextRequest) {
  try {
    const body: MatchRequestBody = await req.json();
    const { bankCode, matchType, bankLineIds, glEntryNos, createdBy } = body;

    if (!bankCode || !matchType) {
      return NextResponse.json({ error: 'ข้อมูลไม่ครบ' }, { status: 400 });
    }
    if (bankLineIds.length === 0 && glEntryNos.length === 0) {
      return NextResponse.json({ error: 'ต้องเลือกอย่างน้อย 1 รายการ' }, { status: 400 });
    }
    if (matchType === 'MATCHED' && (bankLineIds.length === 0 || glEntryNos.length === 0)) {
      return NextResponse.json(
        { error: 'การ Match ต้องเลือกทั้งฝั่ง Bank และฝั่ง GL อย่างน้อยฝั่งละ 1 รายการ' },
        { status: 400 }
      );
    }

    const pool = await getPool();
    const transaction = new sql.Transaction(pool);
    await transaction.begin();

    try {
      const matchRequest = new sql.Request(transaction);
      const matchResult = await matchRequest
        .input('bankCode', sql.NVarChar, bankCode)
        .input('matchType', sql.NVarChar, matchType)
        .input('createdBy', sql.NVarChar, createdBy ?? null)
        .query(`
          INSERT INTO ReconciliationMatch (BankCode, MatchType, CreatedBy)
          OUTPUT INSERTED.MatchId
          VALUES (@bankCode, @matchType, @createdBy)
        `);
      const matchId = matchResult.recordset[0].MatchId;

      for (const lineId of bankLineIds) {
        const r = new sql.Request(transaction);
        await r
          .input('matchId', sql.Int, matchId)
          .input('bankLineId', sql.BigInt, lineId)
          .query(`
            INSERT INTO ReconciliationMatchLine (MatchId, SourceType, BankLineId)
            VALUES (@matchId, 'BANK', @bankLineId)
          `);
      }

      for (const entryNo of glEntryNos) {
        const r = new sql.Request(transaction);
        await r
          .input('matchId', sql.Int, matchId)
          .input('glEntryNo', sql.BigInt, entryNo)
          .query(`
            INSERT INTO ReconciliationMatchLine (MatchId, SourceType, GLEntryNo)
            VALUES (@matchId, 'GL', @glEntryNo)
          `);
      }

      // อัปเดตสถานะฝั่ง BankStatementLine (ฝั่ง GL ไม่มีคอลัมน์สถานะ เช็คผ่าน ReconciliationMatchLine แทน)
      if (bankLineIds.length > 0) {
        const safeIds = bankLineIds.filter((id) => Number.isInteger(id));
        if (safeIds.length !== bankLineIds.length) {
          throw new Error('bankLineIds มีค่าที่ไม่ใช่จำนวนเต็ม');
        }
        const updateRequest = new sql.Request(transaction);
        const idList = safeIds.join(',');
        await updateRequest.query(`
          UPDATE BankStatementLine
          SET MatchStatus = '${matchType}'
          WHERE LineId IN (${idList})
        `);
      }

      await transaction.commit();

      return NextResponse.json({ matchId, matchType, bankLineCount: bankLineIds.length, glEntryCount: glEntryNos.length });
    } catch (err) {
      await transaction.rollback();
      throw err;
    }
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: 'บันทึกการจับคู่ไม่สำเร็จ' }, { status: 500 });
  }
}
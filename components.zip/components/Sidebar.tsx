'use client';

import {
  LayoutDashboard,
  Upload,
  GitCompareArrows,
  Database,
  WalletCards,
  BarChart3,
  Settings,
  LogOut,
  PanelLeftClose,
  PanelLeftOpen,
} from 'lucide-react';

import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';

const menuItems = [
  // {
  //   name: 'Dashboard',
  //   href: '/dashboard',
  //   icon: LayoutDashboard,
  // },
  {
    name: 'Import',
    href: '/import',
    icon: Upload,
  },
  {
    name: 'Reconcile',
    href: '/reconcile',
    icon: GitCompareArrows,
  },
  // {
  //   name: 'Master Data',
  //   href: '/master-data',
  //   icon: Database,
  // },
  {
    name: 'Suspense',
    href: '/suspense',
    icon: WalletCards,
  },
  {
    name: 'Reports',
    href: '/reports',
    icon: BarChart3,
  },
  {
    name: 'Settings',
    href: '/settings',
    icon: Settings,
  },
];

export default function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();

  const [collapsed, setCollapsed] = useState(false);
  const [authorized, setAuthorized] = useState<boolean | null>(null);

  const [user, setUser] = useState<{ name: string; email: string; initials: string } | null>(null);


  useEffect(() => {
   const u = localStorage.getItem('user');
    if (!u) {
      router.push('/login');
      return;
    }
try{
    const parsed = JSON.parse(u);
    const emp = parsed.employee;
    const name = emp
       ? `${emp.First_Name ?? ''} ${emp.Last_Name ?? ''}`.trim() || parsed.username
       : parsed.username;
    const email = emp?.E_Mail ?? parsed.email ?? '';
    let initials = 'NA';
    if (emp?.First_Name || emp?.Last_Name) {
      initials = `${(emp.First_Name?.[0] ?? '')}${(emp.Last_Name?.[0] ?? '')}`.toUpperCase();
    } else if (parsed.username) {
      initials = parsed.username.slice(0, 2).toUpperCase();
    }
    setUser({ name, email, initials });
    setAuthorized(true);
  } catch (err) {
    console.error('Failed to parse user from localStorage', err);
    router.push('/login');
  }
    setAuthorized(true);
  }, [router]);

  if (authorized === null) return null;

  function handleLogout() {
    localStorage.removeItem('user');
    localStorage.removeItem('lastActivity');

    router.push('/login');
  }

  return (
    <aside
      className={`
        fixed left-0 top-0 z-50 flex h-screen flex-col
        border-r border-slate-200/70 bg-white
        transition-all duration-300
        ${collapsed ? 'w-[82px]' : 'w-[300px]'}
      `}
    >

      {/* Logo */}
      <div
        className={`
          flex h-[86px] items-center border-b border-slate-100
          ${collapsed ? 'justify-center' : 'px-6'}
        `}
      >
        <div className="flex items-center gap-3">

          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-sky-500 to-blue-600 shadow-lg shadow-blue-500/20">
            <WalletCards
              size={23}
              className="text-white"
            />
          </div>

          {!collapsed && (
            <div>
              <h1 className="text-[17px] font-bold leading-none text-slate-900">
                Auto Recon
              </h1>

              <span className="text-sm font-medium tracking-[0.18em] text-slate-500">
                365
              </span>
            </div>
          )}

        </div>
      </div>

      {/* Menu */}
      <nav className="flex-1 px-4 py-8">

        {!collapsed && (
          <p className="mb-4 px-4 text-xs font-bold uppercase tracking-[0.18em] text-slate-500">
            Workspace
          </p>
        )}

        <div className="space-y-2">

          {menuItems.map((item) => {
            const Icon = item.icon;

            const isActive =
              pathname === item.href ||
              pathname.startsWith(`${item.href}/`);

            return (
              <button
                key={item.href}
                onClick={() => router.push(item.href)}
                title={collapsed ? item.name : undefined}
                className={`
                  group flex w-full items-center gap-4 rounded-xl
                  px-4 py-3.5 text-left
                  transition-all duration-200

                  ${
                    isActive
                      ? 'bg-blue-100/80 text-blue-700 shadow-sm'
                      : 'text-slate-700 hover:bg-slate-100'
                  }

                  ${collapsed ? 'justify-center px-0' : ''}
                `}
              >

                <Icon
                  size={21}
                  strokeWidth={isActive ? 2.5 : 2}
                  className={`
                    shrink-0 transition-transform
                    group-hover:scale-110
                    ${
                      isActive
                        ? 'text-blue-600'
                        : 'text-slate-700'
                    }
                  `}
                />

                {!collapsed && (
                  <span className="text-[16px] font-medium">
                    {item.name}
                  </span>
                )}

              </button>
            );
          })}

        </div>

      </nav>

      {/* User */}
      <div className="border-t border-slate-100 p-4">

        <div
          className={`
            flex items-center
            ${collapsed ? 'justify-center' : 'gap-3'}
          `}
        >

          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-slate-200 text-sm font-semibold text-slate-600">
            {user?.initials}
          </div>

          {!collapsed && (
            <>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold text-slate-800">
                  {user?.name}
                </p>

                <p className="truncate text-xs text-slate-500">
                  {user?.email}
                </p>
              </div>

              <button
                onClick={handleLogout}
                className="text-slate-500 transition hover:text-red-500"
                title="Logout"
              >
                <LogOut size={20} />
              </button>
            </>
          )}

        </div>

      </div>

      {/* Collapse Button */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-8 flex h-7 w-7 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-500 shadow-sm transition hover:text-blue-600"
      >
        {collapsed ? (
          <PanelLeftOpen size={16} />
        ) : (
          <PanelLeftClose size={16} />
        )}
      </button>

    </aside>
  );
}
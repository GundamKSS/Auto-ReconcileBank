import { NormalizedStatementLine, ParseResult, toISODate, toNumber } from './types';

// KBank: ไฟล์มี header info (เลขบัญชี, ยอดรวม ฯลฯ) อยู่ 10 กว่าแถวแรก ก่อนถึงหัวตารางจริง
// หาแถวหัวตารางแบบ dynamic โดยหาแถวที่มีทั้งคำว่า "Date" และ "Descriptions" อยู่ด้วยกัน
// คอลัมน์จริง (มี merged cell แทรกเป็น null): [_, Date, Time, Descriptions, Withdrawal, _, Deposit, _, Balance, _, Channel, _, Details]
function findHeaderRowIndex(rows: unknown[][]): number {
  const normalize = (s: unknown) => String(s ?? '').replace(/\s+/g, ' ').trim().toLowerCase();
  for (let i = 0; i < rows.length; i++) {
    const cells = rows[i].map(normalize);
    if (cells.includes('date') && cells.some((c) => c.startsWith('description'))) {
      return i;
    }
  }
  return -1;
}

export function parseKBank(rows: unknown[][]): ParseResult {
  const headerRowIndex = findHeaderRowIndex(rows);
  if (headerRowIndex === -1) {
    throw new Error('ไม่พบหัวตารางในไฟล์ KBank — โครงสร้างไฟล์อาจเปลี่ยนไป');
  }

  // คอลัมน์ของ KBank อ้างอิงตำแหน่งคงที่ (fixed index) เพราะมี merged cell ทำให้หาด้วยชื่อไม่แม่นยำ
  const COL = {
    date: 1,
    time: 2,
    description: 3,
    withdrawal: 4,
    deposit: 6,
    balance: 8,
    channel: 10,
    details: 12,
  };

  const lines: NormalizedStatementLine[] = [];

  for (let i = headerRowIndex + 1; i < rows.length; i++) {
    const row = rows[i];
    const tranDate = toISODate(row[COL.date]);
    if (!tranDate) continue;

    const description = String(row[COL.description] ?? '').trim();
    if (description === 'Beginning Balance') continue; // ข้ามแถวยอดยกมา ไม่ใช่ transaction จริง

    lines.push({
      tranDate,
      description,
      debit: toNumber(row[COL.withdrawal]),
      credit: toNumber(row[COL.deposit]),
      balance: toNumber(row[COL.balance]),
      chequeNo: null,
      channel: row[COL.channel] ? String(row[COL.channel]).trim() : null,
      rawDescription: row[COL.details] ? String(row[COL.details]).trim() : null,
    });
  }

  const dates = lines.map((l) => l.tranDate).sort();

  return {
    bankCode: 'KBANK',
    lines,
    periodStart: dates[0] ?? null,
    periodEnd: dates[dates.length - 1] ?? null,
  };
}
"use client";
import React, { useState } from "react";
// แนะนำให้ติดตั้ง lucide-react สำหรับไอคอน: npm install lucide-react
import { 
  FileText, UploadCloud, CheckCircle2, 
  AlertTriangle, ArrowRight, ArrowLeft 
} from "lucide-react";

export default function ImportFlow() {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [selectedSource, setSelectedSource] = useState<"gl" | "bank">("bank");
  const [selectedBank, setSelectedBank] = useState<string>("KBank");

  const banks = ["KBank", "SCB", "BBL", "KTB", "TTB", "BAY"];

  return (
    <div className="min-h-screen bg-slate-50 p-8 font-sans text-slate-800">
      {/* Header Section */}
      <div className="mb-8 flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold mb-1">Import</h1>
          <p className="text-slate-500">Upload Excel files — GL journal or bank statement</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-lg shadow-sm hover:bg-slate-50 transition-colors">
          <UploadCloud size={16} />
          <span className="text-sm font-medium">Download templates</span>
        </button>
      </div>

      {/* Stepper */}
      <div className="flex items-center gap-3 text-sm font-medium text-slate-500 mb-6">
        <div className={`flex items-center gap-2 ${step >= 1 ? "text-blue-600" : ""}`}>
          <span className={`flex items-center justify-center w-6 h-6 rounded-full text-white text-xs ${step >= 1 ? "bg-blue-600" : "bg-slate-300"}`}>1</span>
          Source
        </div>
        <ArrowRight size={14} className="text-slate-300" />
        <div className={`flex items-center gap-2 ${step >= 2 ? "text-blue-600" : ""}`}>
          <span className={`flex items-center justify-center w-6 h-6 rounded-full text-white text-xs ${step >= 2 ? "bg-blue-600" : "bg-slate-300"}`}>2</span>
          Upload & preview
        </div>
        <ArrowRight size={14} className="text-slate-300" />
        <div className={`flex items-center gap-2 ${step === 3 ? "text-blue-600" : ""}`}>
          <span className={`flex items-center justify-center w-6 h-6 rounded-full text-white text-xs ${step === 3 ? "bg-blue-600" : "bg-slate-300"}`}>3</span>
          Map & validate
        </div>
      </div>

      {/* Main Content Card (Glassmorphism effect) */}
      <div className="bg-white/80 backdrop-blur-xl border border-white rounded-3xl shadow-sm p-8 min-h-[500px] flex flex-col">
        
        {/* ================= STEP 1: SOURCE ================= */}
        {step === 1 && (
          <div className="flex-1 flex flex-col">
            <h2 className="text-lg font-semibold mb-6">What are you importing?</h2>
            
            <div className="grid grid-cols-2 gap-4 mb-8">
              {/* GL Card */}
              <div 
                onClick={() => setSelectedSource("gl")}
                className={`p-5 rounded-xl border-2 cursor-pointer transition-all ${
                  selectedSource === "gl" ? "border-blue-500 bg-blue-50/50" : "border-slate-200 hover:border-blue-200"
                }`}
              >
                <div className="flex items-start gap-3">
                  <FileText className={selectedSource === "gl" ? "text-blue-600" : "text-slate-400"} />
                  <div>
                    <h3 className="font-semibold text-slate-800">General Ledger (GL)</h3>
                    <p className="text-sm text-slate-500 mt-1">Journal entries exported from accounting software</p>
                  </div>
                </div>
              </div>

              {/* Bank Card */}
              <div 
                onClick={() => setSelectedSource("bank")}
                className={`p-5 rounded-xl border-2 cursor-pointer transition-all ${
                  selectedSource === "bank" ? "border-blue-300 bg-blue-50/50" : "border-slate-200 hover:border-blue-200"
                }`}
              >
                <div className="flex items-start gap-3">
                  <FileText className={selectedSource === "bank" ? "text-blue-600" : "text-slate-400"} />
                  <div>
                    <h3 className="font-semibold text-slate-800">Bank statement</h3>
                    <p className="text-sm text-slate-500 mt-1">Monthly statement from bank</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Bank Selection (Only shows if Bank is selected) */}
            {selectedSource === "bank" && (
              <div className="mb-auto">
                <p className="text-xs font-bold text-slate-400 mb-3 uppercase tracking-wider">BANK</p>
                <div className="flex flex-wrap gap-2">
                  {banks.map((bank) => (
                    <button
                      key={bank}
                      onClick={() => setSelectedBank(bank)}
                      className={`px-5 py-2 rounded-full text-sm font-medium transition-colors ${
                        selectedBank === bank 
                          ? "bg-blue-500 text-white shadow-md shadow-blue-200" 
                          : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                      }`}
                    >
                      {bank}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-auto flex justify-end">
              <button 
                onClick={() => setStep(2)}
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-full font-medium flex items-center gap-2 transition-colors"
              >
                Continue <ArrowRight size={16} />
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 2: UPLOAD & PREVIEW ================= */}
        {step === 2 && (
          <div className="flex-1 flex flex-col">
            <div className="grid grid-cols-12 gap-8 h-full flex-1">
              {/* Upload Box (Left) */}
              <div className="col-span-4 flex flex-col gap-4">
                <div className="flex-1 border-2 border-dashed border-slate-300 rounded-2xl flex flex-col items-center justify-center p-6 text-center hover:border-blue-400 hover:bg-blue-50/30 transition-colors cursor-pointer bg-slate-50/50">
                  <UploadCloud size={40} className="text-blue-500 mb-4" />
                  <p className="font-semibold text-slate-700">Drag & drop Excel here</p>
                  <p className="text-sm text-slate-500 mt-1">or click to browse - .xlsx, .xls, .csv</p>
                </div>
                {/* File Uploaded Status */}
                <div className="p-4 bg-white border border-slate-200 rounded-xl flex items-center justify-between shadow-sm">
                  <div className="flex items-center gap-3">
                    <FileText size={20} className="text-green-500" />
                    <div>
                      <p className="text-sm font-semibold text-slate-800">kbank-jul-2026.xlsx</p>
                      <p className="text-xs text-slate-500">184 KB · 1,204 rows</p>
                    </div>
                  </div>
                  <CheckCircle2 size={20} className="text-green-500" />
                </div>
              </div>

              {/* Preview Table (Right) */}
              <div className="col-span-8 flex flex-col">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="font-semibold">Preview · first 5 rows</h2>
                  <span className="text-xs text-slate-400">Auto-detected header row · row 1</span>
                </div>
                
                <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm flex-1">
                  <table className="w-full text-sm text-left">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 text-xs font-semibold uppercase">
                      <tr>
                        <th className="px-4 py-3">Date</th>
                        <th className="px-4 py-3">Reference</th>
                        <th className="px-4 py-3">Description</th>
                        <th className="px-4 py-3 text-right">Amount</th>
                        <th className="px-4 py-3">DR/CR</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {[
                        { date: "2026-07-19", ref: "BK-88231", desc: "Customer transfer INV-3391", amt: "128,400.00", type: "CR" },
                        { date: "2026-07-19", ref: "BK-88232", desc: "Supplier payment PO-7712", amt: "42,150.00", type: "DR" },
                        { date: "2026-07-18", ref: "BK-88233", desc: "Batch settlement", amt: "981,220.00", type: "CR" },
                        { date: "2026-07-18", ref: "BK-88234", desc: "Wire fee", amt: "350.00", type: "DR" },
                        { date: "2026-07-17", ref: "BK-88235", desc: "Unidentified deposit", amt: "20,009.00", type: "CR" },
                      ].map((row, i) => (
                        <tr key={i} className="hover:bg-slate-50">
                          <td className="px-4 py-3 text-slate-600">{row.date}</td>
                          <td className="px-4 py-3 text-slate-600">{row.ref}</td>
                          <td className="px-4 py-3 text-slate-800">{row.desc}</td>
                          <td className="px-4 py-3 text-right text-slate-800 tabular-nums">{row.amt}</td>
                          <td className="px-4 py-3 font-medium text-slate-600">{row.type}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="mt-6 flex justify-end gap-3">
                  <button 
                    onClick={() => setStep(1)}
                    className="px-5 py-2.5 text-slate-600 hover:bg-slate-100 rounded-full font-medium transition-colors"
                  >
                    Back
                  </button>
                  <button 
                    onClick={() => setStep(3)}
                    className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-full font-medium flex items-center gap-2 transition-colors"
                  >
                    Map columns <ArrowRight size={16} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================= STEP 3: MAP & VALIDATE ================= */}
        {step === 3 && (
          <div className="flex-1 flex flex-col">
            <div className="grid grid-cols-12 gap-8 h-full">
              
              {/* Mapping (Left) */}
              <div className="col-span-8 flex flex-col">
                <h2 className="font-semibold text-lg">Column mapping</h2>
                <p className="text-sm text-slate-500 mb-4">Confidence ≥ 90% auto-mapped. Review yellow rows.</p>
                
                <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-2 flex flex-col gap-1">
                  {/* Mapping Rows */}
                  {[
                    { source: "Transaction Date", target: "Date", conf: "98%", status: "good" },
                    { source: "Ref No.", target: "Reference", conf: "96%", status: "good" },
                    { source: "Narration", target: "Description", conf: "92%", status: "good" },
                    { source: "Amount (THB)", target: "Amount", conf: "88%", status: "warn" },
                    { source: "Type", target: "Dr/Cr", conf: "74%", status: "warn" },
                  ].map((row, i) => (
                    <div 
                      key={i} 
                      className={`flex items-center justify-between p-3 rounded-lg border border-transparent ${
                        row.status === "warn" ? "bg-yellow-50/50 border-yellow-100" : "hover:bg-slate-50"
                      }`}
                    >
                      <span className="w-1/3 text-sm text-slate-600">{row.source}</span>
                      <ArrowRight size={14} className="text-slate-300" />
                      <span className="w-1/3 text-sm font-semibold text-slate-800 pl-4">{row.target}</span>
                      <span className={`w-16 text-right text-sm font-medium ${row.status === "warn" ? "text-yellow-600" : "text-green-600"}`}>
                        {row.conf}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Validation (Right) */}
              <div className="col-span-4 flex flex-col gap-6">
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6">
                  <h2 className="font-semibold mb-4 text-slate-800">Validation</h2>
                  
                  <div className="flex flex-col gap-3">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 size={18} className="text-green-500 mt-0.5" />
                      <span className="text-sm text-slate-700">1,204 rows parsed</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <CheckCircle2 size={18} className="text-green-500 mt-0.5" />
                      <span className="text-sm text-slate-700">Dates within Jul 2026</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <AlertTriangle size={18} className="text-yellow-500 mt-0.5" />
                      <span className="text-sm text-slate-700">5 rows missing value date</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <AlertTriangle size={18} className="text-yellow-500 mt-0.5" />
                      <span className="text-sm text-slate-700">2 possible duplicates</span>
                    </div>
                  </div>
                </div>

                <div className="mt-auto flex flex-col gap-3">
                  <button className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium shadow-sm transition-colors">
                    Import 1,204 rows
                  </button>
                  <button 
                    onClick={() => setStep(2)}
                    className="w-full py-2.5 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-xl font-medium transition-colors"
                  >
                    Back
                  </button>
                </div>
              </div>

            </div>
          </div>
        )}
      </div>
    </div>
  );
}